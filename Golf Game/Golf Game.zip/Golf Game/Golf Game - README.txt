***********Developed By Juwan Simmons***********
Golf Game 

Goal:
	Get the golf ball in each hole.

Instruction:
	Shoot Your Shot and Replay For More Practice!

Controls:
	Space - Rotate Camera
	Mouse Wheel - Zoom
	Click and Drag - Hit Ball

To Exit:
	Window:
		1. Click The X.

	Full Screen:
		2. Press Windows Button
		3. Then Close Program